function grain() {

    // Opciones para el efecto de grano
    var options = {
        animate: true,
        patternWidth: 100,
        patternHeight: 100,
        grainOpacity: 0.03,
        grainDensity: 1,
        grainWidth: 1,
        grainHeight: 1
    };

    // Aplica el efecto de grano al contenedor con id "XX1"
    grained('', options);
}
