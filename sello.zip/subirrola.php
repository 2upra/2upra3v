<?php
/*
Template Name: Subir Rola
*/
get_header();
?>

<div id="main">
    <div id="content">
		
		<div id="formulariosubirrola">
			<?php echo do_shortcode('[social_post_rolas]'); ?>
		</div>
		
    </div>
</div>

<?php
get_footer();
?>